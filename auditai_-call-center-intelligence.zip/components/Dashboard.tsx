
import React from 'react';
import { AppState } from '../types';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';

const Dashboard: React.FC<{ state: AppState }> = ({ state }) => {
  const avgScore = state.auditResults.length > 0 
    ? (state.auditResults.reduce((acc, curr) => acc + curr.score, 0) / state.auditResults.length).toFixed(1)
    : 0;

  const data = state.auditResults.map((r, i) => ({
    name: `Lig. ${i + 1}`,
    score: r.score
  }));

  const stats = [
    { label: 'Transcrições', value: state.transcriptions.length, icon: '📄', color: 'bg-blue-500' },
    { label: 'Auditadas', value: state.auditResults.length, icon: '🔍', color: 'bg-green-500' },
    { label: 'Score Médio', value: `${avgScore}%`, icon: '⭐', color: 'bg-amber-500' },
    { label: 'Planos Ativos', value: state.offers.length, icon: '📋', color: 'bg-purple-500' },
  ];

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <header>
        <h2 className="text-3xl font-bold text-slate-800">Bem-vindo ao AuditAI</h2>
        <p className="text-slate-500 mt-1">Visão geral do desempenho da sua equipe de vendas.</p>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => (
          <div key={stat.label} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100 flex items-center gap-5">
            <div className={`${stat.color} text-white w-12 h-12 rounded-xl flex items-center justify-center text-xl shadow-lg shadow-current/20`}>
              {stat.icon}
            </div>
            <div>
              <p className="text-sm font-medium text-slate-500 uppercase tracking-tight">{stat.label}</p>
              <p className="text-2xl font-bold text-slate-900">{stat.value}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-white p-8 rounded-3xl shadow-sm border border-slate-100 h-[400px]">
          <h3 className="text-lg font-bold text-slate-800 mb-6">Tendência de Qualidade</h3>
          <ResponsiveContainer width="100%" height="100%">
            {data.length > 0 ? (
              <BarChart data={data}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="name" axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8', fontSize: 12}} />
                <Tooltip 
                  cursor={{fill: '#f8fafc'}}
                  contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgba(0,0,0,0.1)'}}
                />
                <Bar dataKey="score" fill="#3b82f6" radius={[6, 6, 0, 0]} barSize={40} />
              </BarChart>
            ) : (
              <div className="h-full flex items-center justify-center text-slate-400">
                Nenhum dado de auditoria disponível.
              </div>
            )}
          </ResponsiveContainer>
        </div>

        <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100">
          <h3 className="text-lg font-bold text-slate-800 mb-6">Auditorias Recentes</h3>
          <div className="space-y-4 overflow-y-auto max-h-[280px]">
            {state.auditResults.length > 0 ? state.auditResults.map((r) => (
              <div key={r.callId} className="p-4 bg-slate-50 rounded-2xl flex items-center justify-between border border-slate-100 hover:border-blue-200 transition-colors">
                <div>
                  <p className="text-sm font-bold text-slate-800">{r.callId}</p>
                  <p className="text-xs text-slate-500">{r.status.replace('_', ' ')}</p>
                </div>
                <div className={`px-3 py-1 rounded-full text-xs font-bold ${
                  r.score > 80 ? 'bg-green-100 text-green-700' : 
                  r.score > 50 ? 'bg-amber-100 text-amber-700' : 'bg-red-100 text-red-700'
                }`}>
                  {r.score}%
                </div>
              </div>
            )) : (
              <div className="text-center py-10">
                <p className="text-slate-400 italic">Nada para mostrar ainda.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
