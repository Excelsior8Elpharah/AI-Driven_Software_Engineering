import React, { useRef, useState } from 'react';
import { transcribeAudio } from '../services/geminiService';
import { CallTranscription } from '../types';

interface IngestionProps {
  onTranscribed: (t: CallTranscription[]) => void;
  isProcessing: boolean;
  setIsProcessing: (p: boolean) => void;
}

const Ingestion: React.FC<IngestionProps> = ({ onTranscribed, isProcessing, setIsProcessing }) => {
  const [uploadType, setUploadType] = useState<'single' | 'batch'>('single');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const fileToBase64 = (file: File): Promise<string> => {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => {
        const base64String = reader.result as string;
        resolve(base64String.split(',')[1]);
      };
      reader.onerror = error => reject(error);
    });
  };

  const handleProcessFiles = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;

    setIsProcessing(true);
    try {
      const newTranscriptions: CallTranscription[] = [];
      // Fix: Explicitly cast Array.from(files) to File[] so that 'file' in the loop is correctly typed
      const fileList = Array.from(files) as File[];
      for (const file of fileList) {
        const base64 = await fileToBase64(file);
        const result = await transcribeAudio(base64, file.name);
        newTranscriptions.push(result);
      }
      onTranscribed(newTranscriptions);
    } catch (err) {
      console.error(err);
      alert("Erro ao processar áudio. Verifique sua chave API.");
    } finally {
      setIsProcessing(false);
      if (fileInputRef.current) fileInputRef.current.value = "";
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-10">
      <header className="text-center">
        <h2 className="text-4xl font-extrabold text-slate-800 tracking-tight">Ingestão de Inteligência</h2>
        <p className="text-slate-500 mt-3 text-lg">Suba suas ligações para transcrição automática via Gemini 3 Flash.</p>
      </header>

      <div className="flex justify-center gap-4">
        <button 
          onClick={() => setUploadType('single')}
          className={`px-8 py-3 rounded-2xl font-bold transition-all ${uploadType === 'single' ? 'bg-blue-600 text-white shadow-xl shadow-blue-200' : 'bg-white text-slate-500 hover:bg-slate-100'}`}
        >
          Análise Individual
        </button>
        <button 
          onClick={() => setUploadType('batch')}
          className={`px-8 py-3 rounded-2xl font-bold transition-all ${uploadType === 'batch' ? 'bg-blue-600 text-white shadow-xl shadow-blue-200' : 'bg-white text-slate-500 hover:bg-slate-100'}`}
        >
          Processamento em Lote
        </button>
      </div>

      <div 
        className="bg-white border-2 border-dashed border-slate-200 rounded-[2.5rem] p-16 flex flex-col items-center justify-center transition-all hover:border-blue-300 group"
        onClick={() => !isProcessing && fileInputRef.current?.click()}
      >
        <div className="w-24 h-24 bg-blue-50 rounded-full flex items-center justify-center text-5xl mb-6 group-hover:scale-110 transition-transform">
          {uploadType === 'batch' ? '📚' : '🎙️'}
        </div>
        <h3 className="text-xl font-bold text-slate-800">
          {uploadType === 'batch' ? 'Selecione múltiplos arquivos .mp3 ou .wav' : 'Clique para subir uma ligação de teste'}
        </h3>
        <p className="text-slate-400 mt-2 text-center max-w-sm">
          Os áudios serão convertidos em texto e catalogados automaticamente no seu pipeline de auditoria.
        </p>
        <input 
          type="file" 
          multiple={uploadType === 'batch'} 
          ref={fileInputRef} 
          onChange={handleProcessFiles} 
          className="hidden" 
          accept="audio/*" 
        />
        <button 
          disabled={isProcessing}
          className="mt-8 px-10 py-4 bg-slate-900 text-white rounded-2xl font-bold hover:bg-black transition-all disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isProcessing ? 'Processando...' : 'Selecionar Arquivos'}
        </button>
      </div>
    </div>
  );
};

export default Ingestion;