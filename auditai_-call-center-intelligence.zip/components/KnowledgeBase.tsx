
import React, { useRef } from 'react';
import { Offer, Argumentation } from '../types';

interface KBProps {
  offers: Offer[];
  argumentations: Argumentation[];
  onUpdateOffers: (offers: Offer[]) => void;
  onUpdateArgs: (args: Argumentation[]) => void;
}

const KnowledgeBase: React.FC<KBProps> = ({ offers, argumentations, onUpdateOffers, onUpdateArgs }) => {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      // Simple manual CSV parse (CSV logic could be more robust)
      const lines = text.split('\n').filter(line => line.trim());
      const type = file.name.toLowerCase().includes('ofertas') ? 'offers' : 'args';

      if (type === 'offers') {
        const newOffers = lines.slice(1).map(line => {
          const [id, name, description, speed, price, benefits] = line.split(',');
          return { id, name, description, speed, price, keyBenefits: benefits ? benefits.split(';') : [] };
        });
        onUpdateOffers(newOffers);
      } else {
        const newArgs = lines.slice(1).map(line => {
          const [offerId, argumentId, textArg, argType] = line.split(',');
          return { offerId, argumentId, text: textArg, type: argType as any };
        });
        onUpdateArgs(newArgs);
      }
    };
    reader.readAsText(file);
  };

  const downloadCSVTemplate = (type: 'offers' | 'args') => {
    let content = "";
    let filename = "";
    if (type === 'offers') {
      content = "id,name,description,speed,price,keyBenefits\nVIVO_FIBRA_X,Vivo Fibra X,Desc,500 Mega,R$ 120.00,Wi-Fi 6;Gratis";
      filename = "ofertas_template.csv";
    } else {
      content = "offerId,argumentId,text,type\nVIVO_FIBRA_X,ARG_01,Explicar fibra,benefit";
      filename = "argumentacoes_template.csv";
    }
    const blob = new Blob([content], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.click();
  };

  return (
    <div className="space-y-8 max-w-5xl mx-auto">
      <header className="flex justify-between items-end">
        <div>
          <h2 className="text-3xl font-bold text-slate-800">Base de Conhecimento</h2>
          <p className="text-slate-500 mt-1">Configure os planos e argumentos obrigatórios para auditoria.</p>
        </div>
        <div className="flex gap-3">
          <input type="file" ref={fileInputRef} onChange={handleFileUpload} className="hidden" accept=".csv" />
          <button 
            onClick={() => fileInputRef.current?.click()}
            className="px-6 py-2 bg-blue-600 text-white rounded-xl font-semibold hover:bg-blue-700 transition shadow-lg shadow-blue-200"
          >
            Importar CSV
          </button>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <section className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
          <div className="flex justify-between items-center mb-6">
            <h3 className="font-bold text-slate-800 flex items-center gap-2">
              <span className="text-xl">📦</span> Ofertas de Planos
            </h3>
            <button onClick={() => downloadCSVTemplate('offers')} className="text-xs text-blue-600 font-bold hover:underline">Template</button>
          </div>
          <div className="space-y-3">
            {offers.map(offer => (
              <div key={offer.id} className="p-4 border border-slate-100 rounded-2xl bg-slate-50 hover:bg-white hover:shadow-md transition">
                <p className="font-bold text-blue-700 text-sm">{offer.name}</p>
                <p className="text-xs text-slate-500 mt-1">{offer.speed} • {offer.price}</p>
              </div>
            ))}
          </div>
        </section>

        <section className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
          <div className="flex justify-between items-center mb-6">
            <h3 className="font-bold text-slate-800 flex items-center gap-2">
              <span className="text-xl">💬</span> Argumentações
            </h3>
            <button onClick={() => downloadCSVTemplate('args')} className="text-xs text-blue-600 font-bold hover:underline">Template</button>
          </div>
          <div className="space-y-3">
            {argumentations.map(arg => (
              <div key={arg.argumentId} className="p-4 border border-slate-100 rounded-2xl bg-slate-50 hover:bg-white hover:shadow-md transition">
                <div className="flex justify-between items-start">
                  <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400">{arg.offerId}</span>
                  <span className={`text-[10px] px-2 py-0.5 rounded-full font-bold uppercase ${arg.type === 'benefit' ? 'bg-green-100 text-green-700' : 'bg-orange-100 text-orange-700'}`}>
                    {arg.type}
                  </span>
                </div>
                <p className="text-xs text-slate-800 mt-2 line-clamp-2 font-medium">{arg.text}</p>
              </div>
            ))}
          </div>
        </section>
      </div>
    </div>
  );
};

export default KnowledgeBase;
