
import React, { useState } from 'react';
import { AppState, AuditResult } from '../types';

const Auditor: React.FC<{ state: AppState }> = ({ state }) => {
  const [selectedCallId, setSelectedCallId] = useState<string | null>(null);

  const selectedAudit = state.auditResults.find(r => r.callId === selectedCallId);
  const selectedTrans = state.transcriptions.find(t => t.callId === selectedCallId);

  return (
    <div className="space-y-8 h-full flex flex-col">
      <header>
        <h2 className="text-3xl font-bold text-slate-800">Central de Auditoria</h2>
        <p className="text-slate-500 mt-1">Analise detalhadamente cada interação e forneça feedback aos agentes.</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8 flex-1 min-h-0">
        <div className="lg:col-span-1 bg-white rounded-3xl border border-slate-100 shadow-sm flex flex-col overflow-hidden">
          <div className="p-5 border-b border-slate-100 font-bold text-slate-800">Chamadas Auditadas</div>
          <div className="flex-1 overflow-y-auto">
            {state.auditResults.length > 0 ? state.auditResults.map(r => (
              <button
                key={r.callId}
                onClick={() => setSelectedCallId(r.callId)}
                className={`w-full p-5 text-left transition-all border-b border-slate-50 ${selectedCallId === r.callId ? 'bg-blue-50 border-blue-200 border-l-4 border-l-blue-600' : 'hover:bg-slate-50'}`}
              >
                <div className="flex justify-between items-center">
                  <span className="font-bold text-slate-700">{r.callId}</span>
                  <span className="text-xs font-bold text-blue-600">{r.score}%</span>
                </div>
                <div className="mt-1 flex gap-2">
                  <span className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-full ${
                    r.status === 'excellent' ? 'bg-green-100 text-green-700' : 
                    r.status === 'needs_improvement' ? 'bg-red-100 text-red-700' : 'bg-blue-100 text-blue-700'
                  }`}>
                    {r.status.replace('_', ' ')}
                  </span>
                </div>
              </button>
            )) : (
              <div className="p-8 text-center text-slate-400 italic">
                Nenhuma auditoria realizada. Vá para 'Pipeline' e execute o processamento.
              </div>
            )}
          </div>
        </div>

        <div className="lg:col-span-3 space-y-6 overflow-y-auto pb-10">
          {selectedAudit && selectedTrans ? (
            <div className="space-y-8 animate-in fade-in zoom-in-95 duration-300">
              <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm">
                <div className="flex justify-between items-start mb-10">
                  <div>
                    <h3 className="text-2xl font-black text-slate-800 uppercase tracking-tighter">Relatório de Desempenho</h3>
                    <p className="text-slate-400 text-sm font-medium mt-1">Relatório gerado via AuditAI Intelligence • {selectedTrans.dateTime}</p>
                  </div>
                  <div className="flex flex-col items-end">
                    <span className="text-6xl font-black text-blue-600 tabular-nums">{selectedAudit.score}<span className="text-2xl text-blue-400">%</span></span>
                    <span className="text-xs font-bold text-blue-300 uppercase tracking-widest mt-1">Audit Quality Score</span>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                  <div className="space-y-6">
                    <section>
                      <h4 className="text-xs font-black uppercase tracking-widest text-slate-400 mb-3 flex items-center gap-2">
                        <div className="w-1.5 h-1.5 rounded-full bg-green-500"></div> Argumentos Identificados
                      </h4>
                      <div className="flex flex-wrap gap-2">
                        {selectedAudit.mandatoryArgumentsFound.map((arg, i) => (
                          <span key={i} className="px-3 py-1.5 bg-green-50 text-green-700 rounded-xl text-xs font-bold border border-green-100">
                            ✓ {arg}
                          </span>
                        ))}
                      </div>
                    </section>

                    <section>
                      <h4 className="text-xs font-black uppercase tracking-widest text-slate-400 mb-3 flex items-center gap-2">
                        <div className="w-1.5 h-1.5 rounded-full bg-red-500"></div> Argumentos Faltantes
                      </h4>
                      <div className="flex flex-wrap gap-2">
                        {selectedAudit.mandatoryArgumentsMissing.map((arg, i) => (
                          <span key={i} className="px-3 py-1.5 bg-red-50 text-red-700 rounded-xl text-xs font-bold border border-red-100">
                            ✕ {arg}
                          </span>
                        ))}
                      </div>
                    </section>

                    <section>
                      <h4 className="text-xs font-black uppercase tracking-widest text-slate-400 mb-3 flex items-center gap-2">
                        <div className="w-1.5 h-1.5 rounded-full bg-amber-500"></div> Vícios de Linguagem
                      </h4>
                      <div className="flex flex-wrap gap-2">
                        {selectedAudit.vicesOfLanguage.map((vice, i) => (
                          <span key={i} className="px-3 py-1.5 bg-amber-50 text-amber-700 rounded-xl text-xs font-bold border border-amber-100">
                            ⚠️ {vice}
                          </span>
                        ))}
                        {selectedAudit.vicesOfLanguage.length === 0 && <span className="text-xs text-slate-400 italic">Nenhum vício detectado. Excelente fluidez!</span>}
                      </div>
                    </section>
                  </div>

                  <div className="bg-slate-900 rounded-[2rem] p-8 text-white">
                    <h4 className="text-blue-400 text-xs font-black uppercase tracking-widest mb-4">Feedback do Especialista</h4>
                    <p className="text-lg leading-relaxed font-medium text-slate-200 italic">"{selectedAudit.feedback}"</p>
                    <div className="mt-8 pt-6 border-t border-white/10 flex items-center gap-4">
                      <div className="w-10 h-10 rounded-full bg-blue-500 flex items-center justify-center font-bold text-sm">AI</div>
                      <div>
                        <p className="text-sm font-bold">AuditAI Engine 3.1</p>
                        <p className="text-xs text-slate-500">Validation Model X7</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm">
                <h4 className="text-xs font-black uppercase tracking-widest text-slate-400 mb-6">Transcrição Completa da Ligação</h4>
                <div className="bg-slate-50 p-6 rounded-2xl border border-slate-100 text-sm text-slate-700 leading-loose whitespace-pre-wrap font-mono">
                  {selectedTrans.transcript}
                </div>
              </div>
            </div>
          ) : (
            <div className="h-full flex flex-col items-center justify-center text-slate-400 border-4 border-dashed border-slate-100 rounded-[3rem]">
              <div className="text-6xl mb-4">🕵️‍♂️</div>
              <p className="font-bold text-xl">Selecione uma chamada à esquerda</p>
              <p className="mt-1">A análise detalhada aparecerá aqui.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Auditor;
