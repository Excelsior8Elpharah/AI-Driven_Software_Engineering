
import React from 'react';
import { AppView } from '../types';

interface SidebarProps {
  activeView: AppView;
  setView: (view: AppView) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ activeView, setView }) => {
  const items: { id: AppView; label: string; icon: string }[] = [
    { id: 'dashboard', label: 'Painel Geral', icon: '📊' },
    { id: 'knowledge', label: 'Base de Conhecimento', icon: '📚' },
    { id: 'ingestion', label: 'Upload de Áudios', icon: '🎙️' },
    { id: 'pipeline', label: 'Treino e Validação', icon: '⚙️' },
    { id: 'auditor', label: 'Auditoria Final', icon: '✅' },
  ];

  return (
    <aside className="w-72 bg-white border-r border-slate-200 flex flex-col h-full shadow-sm z-10">
      <div className="p-8">
        <div className="flex items-center gap-3">
          <div className="bg-blue-600 p-2 rounded-lg">
            <span className="text-white text-xl font-bold">A</span>
          </div>
          <h1 className="text-xl font-bold bg-gradient-to-r from-blue-700 to-indigo-700 bg-clip-text text-transparent">
            AuditAI
          </h1>
        </div>
        <p className="text-xs text-slate-400 mt-2 font-medium tracking-wider uppercase">Enterprise Edition</p>
      </div>

      <nav className="flex-1 px-4 py-4 space-y-1">
        {items.map((item) => (
          <button
            key={item.id}
            onClick={() => setView(item.id)}
            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all duration-200 ${
              activeView === item.id
                ? 'bg-blue-50 text-blue-700 font-semibold shadow-sm'
                : 'text-slate-500 hover:bg-slate-50 hover:text-slate-900'
            }`}
          >
            <span className="text-lg">{item.icon}</span>
            <span>{item.label}</span>
          </button>
        ))}
      </nav>

      <div className="p-6 border-t border-slate-100">
        <div className="bg-gradient-to-br from-indigo-50 to-blue-50 p-4 rounded-2xl border border-blue-100">
          <p className="text-xs font-semibold text-blue-800 mb-1">Supervisor de Vendas</p>
          <p className="text-sm text-blue-600 truncate">vivo.supervisor@empresa.com</p>
        </div>
      </div>
    </aside>
  );
};

export default Sidebar;
