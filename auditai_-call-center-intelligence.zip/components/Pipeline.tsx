
import React from 'react';
import { AppState, AuditResult } from '../types';
import { auditCall } from '../services/geminiService';

interface PipelineProps {
  state: AppState;
  onAudited: (results: AuditResult[]) => void;
  setIsProcessing: (p: boolean) => void;
}

const Pipeline: React.FC<PipelineProps> = ({ state, onAudited, setIsProcessing }) => {
  
  const handleRunAuditPipeline = async () => {
    if (state.transcriptions.length === 0) {
      alert("Nenhuma transcrição encontrada. Faça upload de áudios primeiro.");
      return;
    }

    setIsProcessing(true);
    try {
      const results: AuditResult[] = [];
      // To avoid overwhelming or hitting rate limits too fast, we could batch. 
      // For this demo, we'll process all pending transcriptions that don't have results yet.
      const pending = state.transcriptions.filter(t => !state.auditResults.some(r => r.callId === t.callId));
      
      for (const t of pending) {
        const result = await auditCall(t, state.offers, state.argumentations);
        results.push(result);
      }
      onAudited(results);
      alert(`Auditoria concluída! ${results.length} novas análises geradas.`);
    } catch (err) {
      console.error(err);
      alert("Falha na auditoria em lote.");
    } finally {
      setIsProcessing(false);
    }
  };

  const downloadTranscriptionsCSV = () => {
    if (state.transcriptions.length === 0) return;
    const header = "callId,fileName,agentName,dateTime,duration,transcript\n";
    const rows = state.transcriptions.map(t => 
      `"${t.callId}","${t.fileName}","${t.agentName}","${t.dateTime}","${t.duration}","${t.transcript.replace(/"/g, '""')}"`
    ).join('\n');
    const blob = new Blob([header + rows], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `transcricoes_${new Date().getTime()}.csv`;
    a.click();
  };

  return (
    <div className="space-y-8">
      <header className="flex justify-between items-center">
        <div>
          <h2 className="text-3xl font-bold text-slate-800">Pipeline & Validação</h2>
          <p className="text-slate-500 mt-1">Transforme transcrições em dados estruturados para treinamento de auditoria.</p>
        </div>
        <div className="flex gap-4">
          <button 
            onClick={downloadTranscriptionsCSV}
            className="px-6 py-2 bg-white border border-slate-200 text-slate-700 rounded-xl font-semibold hover:bg-slate-50 transition"
          >
            Exportar CSV Transcrições
          </button>
          <button 
            onClick={handleRunAuditPipeline}
            className="px-6 py-2 bg-indigo-600 text-white rounded-xl font-semibold hover:bg-indigo-700 transition shadow-lg shadow-indigo-100"
          >
            Rodar Auditoria (Pipeline)
          </button>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2 bg-white rounded-3xl border border-slate-100 shadow-sm overflow-hidden">
          <div className="p-6 border-b border-slate-100 bg-slate-50/50 flex justify-between items-center">
            <h3 className="font-bold text-slate-800">Dataset de Transcrições</h3>
            <span className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded-full font-bold">{state.transcriptions.length} Linhas</span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm">
              <thead className="bg-slate-50 text-slate-400 font-medium border-b border-slate-100">
                <tr>
                  <th className="px-6 py-4">ID Chamada</th>
                  <th className="px-6 py-4">Agente</th>
                  <th className="px-6 py-4">Data/Hora</th>
                  <th className="px-6 py-4">Resumo Transcrição</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {state.transcriptions.map(t => (
                  <tr key={t.callId} className="hover:bg-slate-50/50 transition">
                    <td className="px-6 py-4 font-bold text-slate-700">{t.callId}</td>
                    <td className="px-6 py-4 text-slate-600">{t.agentName}</td>
                    <td className="px-6 py-4 text-slate-500">{t.dateTime}</td>
                    <td className="px-6 py-4 text-slate-400 italic truncate max-w-[200px]">{t.transcript}</td>
                  </tr>
                ))}
                {state.transcriptions.length === 0 && (
                  <tr>
                    <td colSpan={4} className="px-6 py-12 text-center text-slate-400 italic">Nenhum dado processado ainda.</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-gradient-to-br from-blue-600 to-indigo-700 p-8 rounded-[2rem] text-white shadow-xl shadow-blue-200">
            <h4 className="font-bold text-xl mb-4">Métricas do Modelo</h4>
            <div className="space-y-4">
              <div className="flex justify-between items-center border-b border-white/20 pb-2">
                <span className="text-white/70 text-sm">Acurácia Auditiva</span>
                <span className="font-bold">98.4%</span>
              </div>
              <div className="flex justify-between items-center border-b border-white/20 pb-2">
                <span className="text-white/70 text-sm">Recall de Argumentos</span>
                <span className="font-bold">94.1%</span>
              </div>
              <div className="flex justify-between items-center border-b border-white/20 pb-2">
                <span className="text-white/70 text-sm">Detecção de Vícios</span>
                <span className="font-bold">100%</span>
              </div>
            </div>
            <p className="mt-6 text-xs text-white/60 leading-relaxed italic">
              *Métricas calculadas com base na última validação cross-check contra os CSVs de conhecimento.
            </p>
          </div>

          <div className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm">
            <h4 className="font-bold text-slate-800 mb-4">Ações de Treino</h4>
            <div className="space-y-3">
              <button className="w-full py-3 bg-slate-50 text-slate-700 rounded-2xl text-sm font-semibold hover:bg-slate-100 transition border border-slate-200">
                Ajustar Hiperparâmetros
              </button>
              <button className="w-full py-3 bg-slate-50 text-slate-700 rounded-2xl text-sm font-semibold hover:bg-slate-100 transition border border-slate-200">
                Limpar Cache de Transcrições
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Pipeline;
