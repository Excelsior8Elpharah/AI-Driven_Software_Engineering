import { GoogleGenAI, Type } from "@google/genai";
import { AuditResult, CallTranscription, Offer, Argumentation } from "../types";

export async function transcribeAudio(audioBase64: string, fileName: string): Promise<CallTranscription> {
  // Fix: Create instance right before making an API call to ensure latest configuration usage
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  const model = "gemini-3-flash-preview";
  
  const response = await ai.models.generateContent({
    model,
    contents: [
      {
        parts: [
          { inlineData: { data: audioBase64, mimeType: "audio/mp3" } },
          { text: "Transcreva este áudio de ligação de vendas com precisão. Identifique quem fala (Agente vs Cliente). Retorne apenas o texto da transcrição." }
        ]
      }
    ]
  });

  return {
    callId: `CALL_${Math.floor(Math.random() * 10000).toString().padStart(4, '0')}`,
    fileName,
    agentName: "Agente Vivo",
    dateTime: new Date().toLocaleString(),
    duration: "2:45", // Mock duration logic
    transcript: response.text || ""
  };
}

export async function auditCall(
  transcription: CallTranscription, 
  offers: Offer[], 
  argumentations: Argumentation[]
): Promise<AuditResult> {
  // Fix: Create instance right before making an API call to ensure latest configuration usage
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  // Fix: Use gemini-3-pro-preview for complex reasoning and evaluation tasks
  const model = "gemini-3-pro-preview";

  const prompt = `
    Analise a seguinte transcrição de ligação de vendas de call center:
    "${transcription.transcript}"

    Use os seguintes dados de referência:
    Planos Disponíveis: ${JSON.stringify(offers)}
    Argumentações Obrigatórias: ${JSON.stringify(argumentations)}

    Tarefa:
    1. Identifique qual plano foi oferecido.
    2. Liste "vicesOfLanguage" (vícios de linguagem como 'né', 'tipo', 'entendeu').
    3. Identifique quais "mandatoryArgumentsFound" foram ditos pelo agente com base no plano.
    4. Identifique quais "mandatoryArgumentsMissing" o agente esqueceu de mencionar.
    5. Atribua um "score" de 0 a 100 para a qualidade do atendimento.
    6. Dê um "feedback" construtivo para o supervisor.
    7. Defina um "status" entre: 'excellent', 'good', 'needs_improvement', 'poor'.

    Retorne os dados estritamente no formato JSON definido pelo esquema.
  `;

  const response = await ai.models.generateContent({
    model,
    contents: [{ text: prompt }],
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          score: { type: Type.NUMBER },
          vicesOfLanguage: { type: Type.ARRAY, items: { type: Type.STRING } },
          mandatoryArgumentsFound: { type: Type.ARRAY, items: { type: Type.STRING } },
          mandatoryArgumentsMissing: { type: Type.ARRAY, items: { type: Type.STRING } },
          objectionsHandled: { type: Type.ARRAY, items: { type: Type.STRING } },
          feedback: { type: Type.STRING },
          status: { type: Type.STRING }
        },
        required: ["score", "vicesOfLanguage", "mandatoryArgumentsFound", "mandatoryArgumentsMissing", "feedback", "status"]
      }
    }
  });

  const rawJson = JSON.parse(response.text || "{}");
  
  return {
    callId: transcription.callId,
    ...rawJson
  };
}